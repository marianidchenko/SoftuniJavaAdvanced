package Box;

import java.util.ArrayList;
import java.util.List;

public class Box {
    private List<String> values;

    public Box() {
        this.values = new ArrayList<String>();
    }

    public void add(String value) {
        values.add(value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (String value : values) {
            sb.append(String.format("%s: %s%n",value.getClass().getName(), value));
        }
        return sb.toString();
    }
}
